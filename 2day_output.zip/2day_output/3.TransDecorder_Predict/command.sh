TransDecoder.Predict -t ../../3.Transrcipt_assemble/B1_trinity.fasta.Trinity.fasta --retain_blastp_hits ../2.homolgy_search/B1_blast.out --single_best_only
