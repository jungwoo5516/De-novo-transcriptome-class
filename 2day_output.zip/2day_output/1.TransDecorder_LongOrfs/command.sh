TransDecoder.LongOrfs -t ../../3.Transrcipt_assemble/A1_trinity.fasta.Trinity.fasta
