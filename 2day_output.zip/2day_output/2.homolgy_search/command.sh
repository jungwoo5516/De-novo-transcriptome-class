blastp -query ../1.TransDecorder_LongOrfs/A1_trinity.fasta.Trinity.fasta.transdecoder_dir/longest_orfs.pep -db uniprot_DB/uniprot_sprot.fasta -outfmt 6 -evalue 1e-5 > A1_blast.out
