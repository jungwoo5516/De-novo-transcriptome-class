cd-hit -i ../3.TransDecorder_Predict/A1_trinity.fasta.Trinity.fasta.transdecoder.pep -c 0.99 -n 5 -o A1.Trinity.transdecoder.cdhit.pep

cd-hit -i ../3.TransDecorder_Predict/B1_trinity.fasta.Trinity.fasta.transdecoder.pep -c 0.99 -n 5 -o B1.Trinity.transdecoder.cdhit.pep
