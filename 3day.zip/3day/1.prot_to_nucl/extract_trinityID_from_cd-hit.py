import re
import argparse

# 명령줄 인자를 처리하기 위한 argparse 설정
parser = argparse.ArgumentParser(description="FASTA 파일에서 헤더 정보 추출")
parser.add_argument("-i", "--input_file", required=True, help="입력 FASTA 파일 경로")
parser.add_argument("-o", "--output_file", default="output.txt", help="추출 결과를 저장할 파일 경로 (기본값: output.txt)")

args = parser.parse_args()

# 입력 및 출력 파일 경로
input_file = args.input_file
output_file = args.output_file

# 추출 패턴
pattern = r"TRINITY_[^\s:]+:\d+-\d+"

# 추출 결과 저장
with open(input_file, "r") as infile, open(output_file, "w") as outfile:
    for line in infile:
        if line.startswith(">"):
            # 헤더에서 원하는 부분만 추출
            match = re.search(pattern, line)
            if match:
                outfile.write(match.group(0) + "\n")

print(f"추출이 완료되었습니다. 결과는 {output_file}에 저장되었습니다.")
